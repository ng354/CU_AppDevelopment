//
//  ViewController.swift
//  Ng354_P3
//
//  Created by Nikita Gupta on 10/4/14.
//  Copyright (c) 2014 Nikita Gupta. All rights reserved.
//

import UIKit

class Ng354ViewController: UIViewController {
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    
    @IBAction func redArenaEnter(sender: AnyObject) {
    }
    
    
    
    @IBAction func blueArenaEnter(sender: AnyObject) {
    }

}

